function load_octave_packages()

pkg load tsa
%pkg load image
%pkg load statistics
%pkg load geometry
pkg load linear-algebra
pkg load signal

endfunction
